<?php 
    phpinfo();
?>